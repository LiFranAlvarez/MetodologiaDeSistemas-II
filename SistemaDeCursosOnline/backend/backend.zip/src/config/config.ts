export default {
    SECRET : 'ESTE-ES-EL-SECRETO-DE-MI-API'
}