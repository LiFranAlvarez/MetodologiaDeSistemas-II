import React from "react";
import LoginForm from "../components/forms/loginForms";

const LoguinPage: React.FC =()=>{
    return(
        <div style={{ padding: '2rem' }}>
            <LoginForm />
        </div>
    );
};

export default LoguinPage