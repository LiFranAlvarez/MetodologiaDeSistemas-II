export type Material = {
  _id: string;
  tipo: string;
  titulo: string;
  enlace: string;
};
