export interface UserRegisterData {
  nombre: string;
  email: string;
  password: string;
  rol?: string;
  confirmPassword?: string;
}